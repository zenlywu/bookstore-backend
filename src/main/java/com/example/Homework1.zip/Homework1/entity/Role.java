package com.example.Homework1.entity;

public enum Role {
    ADMIN,HR_MANAGER,EMPLOYEE;
}
